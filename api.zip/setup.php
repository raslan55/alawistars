<?php
// setup.php - Run this once to initialize the database tables
// DO NOT leave this exposed on a live production server after running!
require_once 'db.php';

echo "<h1>Database Setup</h1>";

try {
    // 1. Blogs Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS blogs (
        id VARCHAR(255) PRIMARY KEY,
        slug VARCHAR(255) NOT NULL UNIQUE,
        date VARCHAR(255) NOT NULL,
        image LONGTEXT,
        category VARCHAR(255),
        title JSON,
        excerpt JSON,
        content JSON,
        metaTitle JSON,
        metaDescription JSON,
        status VARCHAR(50) DEFAULT 'published'
    )");
    echo "<p>✅ Blogs table ready.</p>";

    // 2. Testimonials Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS testimonials (
        id VARCHAR(255) PRIMARY KEY,
        name_en VARCHAR(255) DEFAULT '',
        name_ar VARCHAR(255) DEFAULT '',
        location_en VARCHAR(255) DEFAULT '',
        location_ar VARCHAR(255) DEFAULT '',
        text_en TEXT,
        text_ar TEXT,
        image LONGTEXT,
        sort_order INT DEFAULT 0,
        active BOOLEAN DEFAULT 1
    )");
    echo "<p>✅ Testimonials table ready.</p>";

    // 3. Partners Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS partners (
        id VARCHAR(255) PRIMARY KEY,
        name VARCHAR(255) DEFAULT '',
        image LONGTEXT,
        sort_order INT DEFAULT 0,
        active BOOLEAN DEFAULT 1
    )");
    echo "<p>✅ Partners table ready.</p>";

    // 4. Site Stats Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS site_stats (
        id VARCHAR(255) PRIMARY KEY,
        stat_key VARCHAR(255) UNIQUE,
        value VARCHAR(255) DEFAULT '',
        label_en VARCHAR(255) DEFAULT '',
        label_ar VARCHAR(255) DEFAULT '',
        icon_color VARCHAR(255) DEFAULT 'bg-blue-500',
        sort_order INT DEFAULT 0
    )");
    echo "<p>✅ Site Stats table ready.</p>";

    // 5. Site Settings Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS site_settings (
        id VARCHAR(255) PRIMARY KEY,
        setting_key VARCHAR(255) UNIQUE,
        value_en LONGTEXT,
        value_ar LONGTEXT
    )");
    echo "<p>✅ Site Settings table ready.</p>";

    // 6. Products Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        id VARCHAR(255) PRIMARY KEY,
        title_en VARCHAR(255) DEFAULT '',
        title_ar VARCHAR(255) DEFAULT '',
        slug VARCHAR(255) NOT NULL UNIQUE,
        image LONGTEXT,
        description_en LONGTEXT,
        description_ar LONGTEXT,
        features JSON,
        active BOOLEAN DEFAULT 1,
        sort_order INT DEFAULT 0
    )");
    echo "<p>✅ Products table ready.</p>";

    // 7. Services Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS services (
        id VARCHAR(255) PRIMARY KEY,
        title_en VARCHAR(255) DEFAULT '',
        title_ar VARCHAR(255) DEFAULT '',
        description_en TEXT,
        description_ar TEXT,
        icon_name VARCHAR(255) DEFAULT 'FaTools',
        sort_order INT DEFAULT 0,
        active BOOLEAN DEFAULT 1
    )");
    echo "<p>✅ Services table ready.</p>";

    // Seed Default Data
    // Stats
    $stmt = $pdo->query("SELECT COUNT(*) FROM site_stats");
    if ($stmt->fetchColumn() == 0) {
        $stats = [
            ['pc', '500+', 'Satisfied Clients', 'عميل راضٍ', 'bg-blue-500', 1],
            ['erp', '1000+', 'ERP Systems', 'نظام ERP', 'bg-indigo-500', 2],
            ['ps', '2000+', 'Support Cases', 'حالة دعم', 'bg-emerald-500', 3],
            ['maintenance', '300+', 'Maintenance', 'صيانة', 'bg-orange-500', 4]
        ];
        $insert = $pdo->prepare("INSERT INTO site_stats (id, stat_key, value, label_en, label_ar, icon_color, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach ($stats as $s) {
            $insert->execute([createId(), $s[0], $s[1], $s[2], $s[3], $s[4], $s[5]]);
        }
        echo "<p>🌱 Seeded default site stats.</p>";
    }

    // Settings
    $stmt = $pdo->query("SELECT COUNT(*) FROM site_settings");
    if ($stmt->fetchColumn() == 0) {
        $keys = ['hero_heading', 'hero_text', 'hero_p', 'team1_name', 'team1_title', 'team1_date', 'team1_bio', 'team1_image', 'team2_name', 'team2_title', 'team2_date', 'team2_bio', 'team2_image'];
        $insert = $pdo->prepare("INSERT INTO site_settings (id, setting_key, value_en, value_ar) VALUES (?, ?, '', '')");
        foreach ($keys as $k) {
            $insert->execute([createId(), $k]);
        }
        echo "<p>🌱 Seeded default site settings.</p>";
    }

    // Products
    $stmt = $pdo->query("SELECT COUNT(*) FROM products");
    if ($stmt->fetchColumn() == 0) {
        $insert = $pdo->prepare("INSERT INTO products (id, title_en, title_ar, slug, image, description_en, description_ar, features, active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $features = json_encode([["en" => "Multi-branch", "ar" => "تعدد الفروع"]]);
        $insert->execute([createId(), "Accounting & Inventory", "نظام المحاسبة والمستودعات", "accounting-inventory", "", "Full accounting and inventory system...", "نظام محاسبي ومخزني متكامل...", $features, 1, 1]);
        echo "<p>🌱 Seeded default products.</p>";
    }

    // Services
    $stmt = $pdo->query("SELECT COUNT(*) FROM services");
    if ($stmt->fetchColumn() == 0) {
        $insert = $pdo->prepare("INSERT INTO services (id, title_en, title_ar, description_en, description_ar, icon_name, sort_order, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $insert->execute([createId(), "Technical Support", "الدعم الفني", "24/7 technical support...", "دعم فني على مدار الساعة...", "FaTools", 1, 1]);
        echo "<p>🌱 Seeded default services.</p>";
    }

    echo "<h3>Setup Complete! 🎉</h3>";
    echo "<p>You should now delete or rename this setup.php file for security.</p>";

} catch (PDOException $e) {
    echo "<h3>Error during setup:</h3>";
    echo "<pre>" . $e->getMessage() . "</pre>";
}
?>
